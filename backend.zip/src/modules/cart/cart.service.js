const ApiError = require("../utils/ApiError");
const cartRepo = require("./cart.repository");
const Product = require("../products/product.model");

class CartService {

async addToCart(userId, data) {
    const { productId, variantLabel, quantity } = data;

    const product = await Product.findOne({
      _id: productId,
      isActive: true,
    });

    if (!product) throw new ApiError("Product not found", 404);

    const variant = product.variants.find(
      v => v.label === variantLabel
    );

    if (!variant) throw new ApiError("Variant not found", 404);

    if (variant.stock < quantity)
      throw new ApiError("Insufficient stock", 400);

    let cart = await cartRepo.findByUserId(userId);

    if (!cart) {
      cart = await cartRepo.create({
        userId,
        items: [
          {
            productId,
            variantLabel,
            price: variant.price,
            quantity,
          },
        ],
      });
      return cart;
    }

      const existingItem = cart.items.find(
      (i) =>
        i.productId._id.toString() === productId.toString() &&
        i.variantLabel === variantLabel
    );


    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      cart.items.push({
        productId,
        variantLabel,
        price: variant.price,
        quantity,
      });
    }

    await cartRepo.update(cart);
    return cartRepo.findByUserId(userId);
  }


async getCart(userId) {
  let cart = await cartRepo.findByUserId(userId);

  if (!cart) {
    return {
      userId,
      items: [],
    };
  }

  cart.items = cart.items.filter(
    (i) => i.productId && i.productId.images?.length > 0
  );

  await cart.save();
  return cart;
}



async updateCartItem(userId, productId, variantLabel, quantity) {

    const cart = await cartRepo.findByUserId(userId);

    if (!cart) throw new ApiError("Cart not found", 404);

    const item = cart.items.find(
  (i) =>
    i.productId._id.toString() === productId.toString() &&
    i.variantLabel === variantLabel
    );


    if (!item) throw new ApiError("Cart item not found", 404);

    if (quantity < 1) {
      cart.items = cart.items.filter(i => i !== item);
    } else {
      item.quantity = quantity;
    }

    await cartRepo.update(cart);
    return cartRepo.findByUserId(userId);

}


async removeItem(userId, productId, variantLabel) {
    const cart = await cartRepo.findByUserId(userId);
    if (!cart) throw new ApiError("Cart not found", 404);

   cart.items = cart.items.filter(
  (i) =>
    !(
      i.productId._id.toString() === productId.toString() &&
      i.variantLabel === variantLabel
    )
);


    await cartRepo.update(cart);
    return cartRepo.findByUserId(userId);

}


async clearCart(userId) {
    await cartRepo.clearCart(userId);
    return cartRepo.findByUserId(userId);

}


}












module.exports = new CartService();